<?php
session_start();

include "../config/koneksi.php";

$email = $_POST['email'];
$password = md5($_POST['password']);

$data = mysqli_query($conn,"
SELECT * FROM user
WHERE email='$email'
AND password='$password'
");

$cek = mysqli_num_rows($data);

if($cek > 0){

    $d = mysqli_fetch_assoc($data);

    $_SESSION['id_user'] = $d['id_user'];
    $_SESSION['nama'] = $d['nama'];

    header("Location: ../mahasiswa/dashboard.php");

}else{

    echo "
    <script>
        alert('Login gagal');
        window.location='../login.php';
    </script>
    ";
}
?>