<?php
session_start();
include '../config/koneksi.php';

$id_user = $_SESSION['id_user'];

$foto = $_FILES['foto']['name'];
$ijazah = $_FILES['ijazah']['name'];
$rapor = $_FILES['rapor']['name'];

$tmp_foto = $_FILES['foto']['tmp_name'];
$tmp_ijazah = $_FILES['ijazah']['tmp_name'];
$tmp_rapor = $_FILES['rapor']['tmp_name'];

move_uploaded_file($tmp_foto, "../uploads/".$foto);
move_uploaded_file($tmp_ijazah, "../uploads/".$ijazah);
move_uploaded_file($tmp_rapor, "../uploads/".$rapor);

$query = mysqli_query($conn, "

INSERT INTO berkas (

    id_user,
    foto,
    ijazah,
    rapor

)

VALUES (

    '$id_user',
    '$foto',
    '$ijazah',
    '$rapor'

)

");

if($query){

    echo "
    <script>
        alert('Upload berhasil!');
        window.location='../mahasiswa/dashboard.php';
    </script>
    ";

}else{

    echo "
    <script>
        alert('Upload gagal!');
        window.location='../mahasiswa/upload-berkas.php';
    </script>
    ";

}
?>