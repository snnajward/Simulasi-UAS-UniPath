<?php
session_start();
include '../config/koneksi.php';

$id_user = $_SESSION['id_user'];

$nik = $_POST['nik'];
$nisn = $_POST['nisn'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$tempat_lahir = $_POST['tempat_lahir'];
$tanggal_lahir = $_POST['tanggal_lahir'];
$alamat = $_POST['alamat'];
$no_hp = $_POST['no_hp'];
$asal_sekolah = $_POST['asal_sekolah'];
$jurusan_pilihan = $_POST['jurusan_pilihan'];

$query = mysqli_query($conn, "

INSERT INTO pendaftaran (

    id_user,
    nik,
    nisn,
    jenis_kelamin,
    tempat_lahir,
    tanggal_lahir,
    alamat,
    no_hp,
    asal_sekolah,
    jurusan_pilihan

)

VALUES (

    '$id_user',
    '$nik',
    '$nisn',
    '$jenis_kelamin',
    '$tempat_lahir',
    '$tanggal_lahir',
    '$alamat',
    '$no_hp',
    '$asal_sekolah',
    '$jurusan_pilihan'

)

");

if($query){

    echo "
    <script>
        alert('Pendaftaran berhasil!');
        window.location='../mahasiswa/dashboard.php';
    </script>
    ";

}else{

    echo "
    <script>
        alert('Pendaftaran gagal!');
        window.location='../mahasiswa/pendaftaran.php';
    </script>
    ";

}
?>