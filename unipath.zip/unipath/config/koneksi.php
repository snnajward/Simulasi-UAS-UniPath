<?php

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "unipath"
);

if(!$conn){
    die("Koneksi gagal");
}
?>