<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register UniPath</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
            background: linear-gradient(135deg,#0D1B2A,#1B263B);
            min-height:100vh;
            display:flex;
            justify-content:center;
            align-items:center;
        }

        .register-card{
            width:100%;
            max-width:450px;
            border:none;
            border-radius:25px;
            overflow:hidden;
            box-shadow:0 10px 30px rgba(0,0,0,0.3);
        }

        .top-box{
            background:#415A77;
            color:white;
            padding:35px;
            text-align:center;
        }

        .btn-register{
            background:#1B263B;
            color:white;
            border:none;
        }

        .btn-register:hover{
            background:#0D1B2A;
        }
    </style>
</head>
<body>

<div class="card register-card">

    <div class="top-box">
        <h2 class="fw-bold">UniPath</h2>
        <p class="mb-0">Create Student Account</p>
    </div>

    <div class="card-body p-4">

        <form action="proses/register-proses.php" method="POST">

            <div class="mb-3">
                <label>Nama Lengkap</label>
                <input type="text" name="nama" class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="mb-3">
                <label>No HP</label>
                <input type="text" name="no_hp" class="form-control">
            </div>

            <div class="mb-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <button class="btn btn-register w-100 py-2">
                Daftar Sekarang
            </button>

        </form>

        <p class="text-center mt-3">
            Sudah punya akun?
            <a href="login.php">Login</a>
        </p>

    </div>

</div>

</body>
</html>