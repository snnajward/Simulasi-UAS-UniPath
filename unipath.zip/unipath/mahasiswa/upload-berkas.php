<?php
session_start();

if(!isset($_SESSION['id_user'])){
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Upload Berkas</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#F5F7FA;
}

.card-upload{
    border:none;
    border-radius:20px;
    box-shadow:0 5px 20px rgba(0,0,0,0.08);
}
        .sidebar{
            width:260px;
            min-height:100vh;
            background:linear-gradient(180deg,#1B263B,#415A77);
            color:white;
            position:fixed;
            padding:30px 20px;
        }

        .sidebar h3{
            font-weight:bold;
            margin-bottom:20px;
        }

        .sidebar a{
            display:block;
            color:#ddd;
            text-decoration:none;
            padding:14px 15px;
            border-radius:12px;
            margin-bottom:12px;
            transition:.3s;
            font-weight:500;
        }

        .sidebar a:hover,
        .sidebar a.active{
            background:rgba(255,255,255,0.15);
            color:white;
            transform:translateX(5px);
        }
</style>

</head>
<body>

<div class="container py-5">

<div class="card card-upload p-5">

<h2 class="fw-bold mb-4">
📂 Upload Berkas
</h2>

<form action="../proses/upload-proses.php" method="POST" enctype="multipart/form-data">

<div class="mb-3">
<label>Upload Foto</label>
<input type="file" name="foto" class="form-control" required>
</div>

<div class="mb-3">
<label>Upload Ijazah</label>
<input type="file" name="ijazah" class="form-control" required>
</div>

<div class="mb-3">
<label>Upload Rapor</label>
<input type="file" name="rapor" class="form-control" required>
</div>

<button class="btn btn-primary w-100">
Upload Berkas
</button>

</form>

</div>

</div>

</body>
</html>