<?php
session_start();

if(!isset($_SESSION['id_user'])){
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Daftar Ulang</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#F5F7FA;
}
.card-box{
    border:none;
    border-radius:20px;
    box-shadow:0 5px 20px rgba(0,0,0,0.08);
}
</style>
</head>
<body>



<div class="container py-5">

<div class="card card-box p-5">

<h2 class="fw-bold mb-4">💳 Daftar Ulang</h2>

<form>

<label>Nama Lengkap</label>
<input type="text" class="form-control mb-3">

<label>Bukti Pembayaran</label>
<input type="file" class="form-control mb-4">

<button class="btn btn-primary">
    Submit
</button>

</form>

</div>

</div>

</body>
</html>