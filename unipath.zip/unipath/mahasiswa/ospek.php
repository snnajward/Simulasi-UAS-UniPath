<?php
session_start();

if(!isset($_SESSION['id_user'])){
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Ospek Mahasiswa</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#F5F7FA;
}
.card-box{
    border:none;
    border-radius:20px;
    box-shadow:0 5px 20px rgba(0,0,0,0.08);
}
        .sidebar{
            width:260px;
            min-height:100vh;
            background:linear-gradient(180deg,#1B263B,#415A77);
            color:white;
            position:fixed;
            padding:30px 20px;
        }

        .sidebar h3{
            font-weight:bold;
            margin-bottom:20px;
        }

        .sidebar a{
            display:block;
            color:#ddd;
            text-decoration:none;
            padding:14px 15px;
            border-radius:12px;
            margin-bottom:12px;
            transition:.3s;
            font-weight:500;
        }

        .sidebar a:hover,
        .sidebar a.active{
            background:rgba(255,255,255,0.15);
            color:white;
            transform:translateX(5px);
        }
</style>
</head>
<body>


<div class="container py-5">

<div class="card card-box p-5 text-center">

<h2 class="fw-bold mb-4">🎉 Ospek Mahasiswa Baru</h2>

<p>
Selamat datang di UniPath!
</p>

<div class="alert alert-info">
    Jadwal ospek akan diumumkan setelah daftar ulang selesai.
</div>

<a href="dashboard.php" class="btn btn-dark">
    Kembali ke Dashboard
</a>

</div>

</div>

</body>
</html>