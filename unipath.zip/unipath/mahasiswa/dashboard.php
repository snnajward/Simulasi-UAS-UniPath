<?php
session_start();

if(!isset($_SESSION['id_user'])){
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Mahasiswa - UniPath</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

        body{
            background:#F5F7FA;
            overflow-x:hidden;
        }

        .sidebar{
            width:260px;
            min-height:100vh;
            background:linear-gradient(180deg,#1B263B,#415A77);
            color:white;
            position:fixed;
            padding:30px 20px;
        }

        .sidebar h3{
            font-weight:bold;
            margin-bottom:20px;
        }

        .sidebar a{
            display:block;
            color:#ddd;
            text-decoration:none;
            padding:14px 15px;
            border-radius:12px;
            margin-bottom:12px;
            transition:.3s;
            font-weight:500;
        }

        .sidebar a:hover,
        .sidebar a.active{
            background:rgba(255,255,255,0.15);
            color:white;
            transform:translateX(5px);
        }

        .content{
            margin-left:280px;
            padding:35px;
        }

        .topbar{
            background:white;
            border-radius:20px;
            padding:25px;
            margin-bottom:30px;
            box-shadow:0 5px 20px rgba(0,0,0,0.06);
        }

        .card-custom{
            border:none;
            border-radius:20px;
            box-shadow:0 5px 20px rgba(0,0,0,0.06);
            transition:.3s;
        }

        .card-custom:hover{
            transform:translateY(-5px);
        }

        .step-box{
            border:none;
            border-left:6px solid #1B263B;
            border-radius:18px;
            box-shadow:0 5px 20px rgba(0,0,0,0.05);
            transition:.3s;
        }

        .step-box:hover{
            transform:translateY(-5px);
        }

        .welcome-box{
            background:linear-gradient(135deg,#1B263B,#415A77);
            color:white;
            border-radius:25px;
            padding:40px;
            margin-bottom:30px;
        }

        .badge-status{
            background:#FFF3CD;
            color:#856404;
            padding:10px 18px;
            border-radius:30px;
            font-size:14px;
            font-weight:bold;
        }

        .mini-icon{
            width:60px;
            height:60px;
            border-radius:15px;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:28px;
            margin:auto;
            margin-bottom:15px;
            background:#E9EEF5;
        }

        @media(max-width:992px){

            .sidebar{
                position:relative;
                width:100%;
                min-height:auto;
            }

            .content{
                margin-left:0;
                padding:20px;
            }

        }

    </style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">

    <h3>🎓 UniPath</h3>

    <p class="mb-4">
        Halo,
        <br>
        <strong><?= $_SESSION['nama']; ?></strong>
    </p>

    <a class="active" href="dashboard.php">
        🏠 Dashboard
    </a>

    <a href="pendaftaran.php">
        📝 Pendaftaran
    </a>

    <a href="upload-berkas.php">
        📂 Upload Berkas
    </a>

    <a href="ujian.php">
        🧪 Ujian Masuk
    </a>

    <a href="pengumuman.php">
        📢 Pengumuman
    </a>

    <a href="daftar-ulang.php">
        💳 Daftar Ulang
    </a>

    <a href="ospek.php">
        🎉 Ospek
    </a>

    <a href="../logout.php">
        🚪 Logout
    </a>

</div>

<!-- CONTENT -->
<div class="content">

    <!-- TOPBAR -->
    <div class="topbar d-flex justify-content-between align-items-center flex-wrap">

        <div>
            <h2 class="fw-bold">
                Dashboard Mahasiswa
            </h2>

            <p class="text-muted mb-0">
                Sistem Penerimaan Mahasiswa Baru UniPath
            </p>
        </div>

        <div class="badge-status mt-3 mt-md-0">
            ⏳ Status: Menunggu Seleksi
        </div>

    </div>

    <!-- WELCOME -->
    <div class="welcome-box">

        <h1 class="fw-bold">
            Selamat Datang 👋
        </h1>

        <p class="mt-3 fs-5">
            Pantau proses pendaftaran, upload berkas,
            dan lihat pengumuman hasil seleksi melalui dashboard UniPath.
        </p>

    </div>

    <!-- STATUS -->
    <div class="row g-4">

        <div class="col-md-4">
            <div class="card card-custom p-4 text-center">

                <div class="mini-icon">
                    📚
                </div>

                <h5>Total Tahapan</h5>

                <h1 class="fw-bold text-primary">
                    6
                </h1>

            </div>
        </div>

        <div class="col-md-4">
            <div class="card card-custom p-4 text-center">

                <div class="mini-icon">
                    📂
                </div>

                <h5>Status</h5>

                <h1 class="fw-bold text-warning">
                    Proses
                </h1>

            </div>
        </div>

        <div class="col-md-4">
            <div class="card card-custom p-4 text-center">

                <div class="mini-icon">
                    ✅
                </div>

                <h5>Akun</h5>

                <h1 class="fw-bold text-success">
                    Aktif
                </h1>

            </div>
        </div>

    </div>

    <!-- FLOW -->
    <div class="mt-5">

        <h3 class="fw-bold mb-4">
            🚀 Alur Pendaftaran Mahasiswa
        </h3>

        <div class="row g-4">

            <div class="col-md-6">
                <div class="card step-box p-4">
                    <h5>✅ Registrasi Akun</h5>
                    <p class="mb-0">
                        Akun berhasil dibuat dan siap digunakan.
                    </p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card step-box p-4">
                    <h5>📝 Isi Form Pendaftaran</h5>
                    <p class="mb-0">
                        Lengkapi seluruh data diri mahasiswa.
                    </p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card step-box p-4">
                    <h5>📂 Upload Berkas</h5>
                    <p class="mb-0">
                        Upload dokumen persyaratan pendaftaran.
                    </p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card step-box p-4">
                    <h5>🧪 Ujian Masuk</h5>
                    <p class="mb-0">
                        Mengikuti ujian seleksi masuk universitas.
                    </p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card step-box p-4">
                    <h5>📢 Pengumuman</h5>
                    <p class="mb-0">
                        Hasil seleksi akan diumumkan pada dashboard.
                    </p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card step-box p-4">
                    <h5>🎉 Ospek Mahasiswa</h5>
                    <p class="mb-0">
                        Mengikuti orientasi mahasiswa baru UniPath.
                    </p>
                </div>
            </div>

        </div>

    </div>

</div>

</body>
</html>