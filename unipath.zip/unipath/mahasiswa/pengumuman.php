<?php
session_start();

if(!isset($_SESSION['id_user'])){
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Pengumuman</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#F5F7FA;
}
.card-box{
    border:none;
    border-radius:20px;
    box-shadow:0 5px 20px rgba(0,0,0,0.08);
}
        .sidebar{
            width:260px;
            min-height:100vh;
            background:linear-gradient(180deg,#1B263B,#415A77);
            color:white;
            position:fixed;
            padding:30px 20px;
        }

        .sidebar h3{
            font-weight:bold;
            margin-bottom:20px;
        }

        .sidebar a{
            display:block;
            color:#ddd;
            text-decoration:none;
            padding:14px 15px;
            border-radius:12px;
            margin-bottom:12px;
            transition:.3s;
            font-weight:500;
        }

        .sidebar a:hover,
        .sidebar a.active{
            background:rgba(255,255,255,0.15);
            color:white;
            transform:translateX(5px);
        }
</style>
</head>
<body>

<div class="container py-5">

<div class="card card-box p-5 text-center">

<h2 class="fw-bold mb-4">📢 Pengumuman</h2>

<div class="alert alert-success">
    Selamat! Anda dinyatakan <strong>LULUS</strong> seleksi PMB UniPath.
</div>

<a href="daftar-ulang.php" class="btn btn-success">
    Lanjut Daftar Ulang
</a>

</div>

</div>

</body>
</html>