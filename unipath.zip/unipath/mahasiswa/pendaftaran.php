<?php
session_start();

if(!isset($_SESSION['id_user'])){
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Pendaftaran Mahasiswa</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#F5F7FA;
}

.card-form{
    border:none;
    border-radius:20px;
    box-shadow:0 5px 20px rgba(0,0,0,0.08);
}
        .sidebar{
            width:260px;
            min-height:100vh;
            background:linear-gradient(180deg,#1B263B,#415A77);
            color:white;
            position:fixed;
            padding:30px 20px;
        }

        .sidebar h3{
            font-weight:bold;
            margin-bottom:20px;
        }

        .sidebar a{
            display:block;
            color:#ddd;
            text-decoration:none;
            padding:14px 15px;
            border-radius:12px;
            margin-bottom:12px;
            transition:.3s;
            font-weight:500;
        }

        .sidebar a:hover,
        .sidebar a.active{
            background:rgba(255,255,255,0.15);
            color:white;
            transform:translateX(5px);
        }
</style>

</head>
<body>

<div class="container py-5">

<div class="card card-form p-5">

<h2 class="fw-bold mb-4">
📝 Formulir Pendaftaran
</h2>

<form action="../proses/pendaftaran-proses.php" method="POST">

<div class="row">

<div class="col-md-6 mb-3">
<label>Nama Lengkap</label>
<input type="text" name="nama" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>NIK</label>
<input type="text" name="nik" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>NISN</label>
<input type="text" name="nisn" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>No HP</label>
<input type="text" name="no_hp" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>Tempat Lahir</label>
<input type="text" name="tempat_lahir" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>Tanggal Lahir</label>
<input type="date" name="tanggal_lahir" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>Jenis Kelamin</label>

<select name="jenis_kelamin" class="form-control" required>
<option value="">-- Pilih --</option>
<option>Laki-laki</option>
<option>Perempuan</option>
</select>

</div>

<div class="col-md-6 mb-3">
<label>Jurusan Pilihan</label>

<select name="jurusan_pilihan" class="form-control" required>
<option value="">-- Pilih Jurusan --</option>
<option>Teknik Informatika</option>
<option>Sistem Informasi</option>
<option>Manajemen</option>
<option>Akuntansi</option>
</select>

</div>

<div class="col-12 mb-3">
<label>Alamat</label>
<textarea name="alamat" class="form-control" rows="4"></textarea>
</div>

<div class="col-12 mb-3">
<label>Asal Sekolah</label>
<input type="text" name="asal_sekolah" class="form-control">
</div>

</div>

<button class="btn btn-primary w-100">
Simpan Pendaftaran
</button>

</form>

</div>

</div>

</body>
</html>