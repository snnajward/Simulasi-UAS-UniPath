<?php
session_start();

if(!isset($_SESSION['id_admin'])){
    header("Location: login.php");
    exit;
}

include "../config/koneksi.php";

$totalUser = mysqli_num_rows(mysqli_query($conn,"
SELECT * FROM user
"));

$totalPendaftaran = mysqli_num_rows(mysqli_query($conn,"
SELECT * FROM pendaftaran
"));
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard Admin</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#F5F7FA;
}

.sidebar{
    width:250px;
    min-height:100vh;
    background:#1B263B;
    color:white;
    position:fixed;
    padding:30px 20px;
}

.sidebar a{
    display:block;
    color:#ddd;
    text-decoration:none;
    padding:12px;
    border-radius:10px;
    margin-bottom:10px;
}

.sidebar a:hover{
    background:#415A77;
    color:white;
}

.content{
    margin-left:270px;
    padding:30px;
}

.card-box{
    border:none;
    border-radius:20px;
    box-shadow:0 5px 20px rgba(0,0,0,0.08);
}
</style>
</head>

<body>

<div class="sidebar">

<h3>🛠 Admin Panel</h3>

<p>
Halo,
<br>
<strong><?= $_SESSION['username_admin']; ?></strong>
</p>

<hr>

<a href="dashboard.php">🏠 Dashboard</a>
<a href="data-mahasiswa.php">👨‍🎓 Data Mahasiswa</a>
<a href="../logout.php">🚪 Logout</a>

</div>

<div class="content">

<h2 class="fw-bold mb-4">
Dashboard Admin
</h2>

<div class="row g-4">

<div class="col-md-6">
<div class="card card-box p-4 text-center">

<h5>Total User</h5>

<h1 class="fw-bold text-primary">
<?= $totalUser; ?>
</h1>

</div>
</div>

<div class="col-md-6">
<div class="card card-box p-4 text-center">

<h5>Total Pendaftar</h5>

<h1 class="fw-bold text-success">
<?= $totalPendaftaran; ?>
</h1>

</div>
</div>

</div>

</div>

</body>
</html>