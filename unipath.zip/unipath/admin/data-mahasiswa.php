<?php
session_start();

if(!isset($_SESSION['id_admin'])){
    header("Location: login.php");
    exit;
}

include "../config/koneksi.php";

if(isset($_GET['status'])){

    $id = $_GET['id'];
    $status = $_GET['status'];

    mysqli_query($conn,"
    UPDATE pendaftaran
    SET status_pendaftaran='$status'
    WHERE id_pendaftaran='$id'
    ");

    header("Location: data-mahasiswa.php");
}

$data = mysqli_query($conn,"
SELECT p.*, u.nama
FROM pendaftaran p
JOIN user u ON p.id_user = u.id_user
ORDER BY p.id_pendaftaran DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Data Mahasiswa</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#F5F7FA;
}

.card-box{
    border:none;
    border-radius:20px;
    box-shadow:0 5px 20px rgba(0,0,0,0.08);
}
</style>
</head>

<body>

<div class="container py-5">

<div class="card card-box p-5">

<h2 class="fw-bold mb-4">
👨‍🎓 Data Pendaftar
</h2>

<table class="table table-bordered table-hover align-middle">

<tr class="table-dark">
<th>No</th>
<th>Nama</th>
<th>NIK</th>
<th>NISN</th>
<th>Jurusan</th>
<th>Status</th>
<th>Aksi</th>
</tr>

<?php
$no = 1;

while($d = mysqli_fetch_array($data)){
?>

<tr>

<td><?= $no++; ?></td>

<td><?= $d['nama']; ?></td>

<td><?= $d['nik']; ?></td>

<td><?= $d['nisn']; ?></td>

<td><?= $d['jurusan_pilihan']; ?></td>

<td>

<?php if($d['status_pendaftaran']=="Menunggu"){ ?>
<span class="badge bg-warning text-dark">
    Menunggu
</span>

<?php } elseif($d['status_pendaftaran']=="Lulus"){ ?>
<span class="badge bg-success">
    Lulus
</span>

<?php } else { ?>
<span class="badge bg-danger">
    Tidak Lulus
</span>
<?php } ?>

</td>

<td>

<a href="?id=<?= $d['id_pendaftaran']; ?>&status=Lulus"
class="btn btn-success btn-sm">
Lulus
</a>

<a href="?id=<?= $d['id_pendaftaran']; ?>&status=Tidak Lulus"
class="btn btn-danger btn-sm">
Tidak Lulus
</a>

</td>

</tr>

<?php } ?>

</table>

<a href="dashboard.php" class="btn btn-dark">
    Kembali
</a>

</div>

</div>

</body>
</html>