<?php
session_start();
include "../config/koneksi.php";

if(isset($_POST['login'])){

    $username = $_POST['username'];
    $password = md5($_POST['password']);

    $data = mysqli_query($conn,"
    SELECT * FROM admin
    WHERE username='$username'
    AND password='$password'
    ");

    $cek = mysqli_num_rows($data);

    if($cek > 0){

        $d = mysqli_fetch_assoc($data);

        $_SESSION['id_admin'] = $d['id_admin'];
        $_SESSION['username_admin'] = $d['username'];

        header("Location: dashboard.php");

    }else{

        echo "
        <script>
            alert('Login gagal');
        </script>
        ";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Login Admin</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#F5F7FA;
}

.card-box{
    border:none;
    border-radius:20px;
    box-shadow:0 5px 20px rgba(0,0,0,0.08);
}
</style>
</head>

<body>

<div class="container py-5">

<div class="row justify-content-center">

<div class="col-md-4">

<div class="card card-box p-5">

<h2 class="fw-bold text-center mb-4">
🛠 Admin UniPath
</h2>

<form method="POST">

<label>Username</label>
<input type="text" name="username" class="form-control mb-3">

<label>Password</label>
<input type="password" name="password" class="form-control mb-4">

<button class="btn btn-dark w-100" name="login">
    Login Admin
</button>

</form>

</div>

</div>

</div>

</div>

</body>
</html>